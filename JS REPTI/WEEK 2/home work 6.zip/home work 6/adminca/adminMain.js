
import { getData } from "./adAssinhron.js";
getData()