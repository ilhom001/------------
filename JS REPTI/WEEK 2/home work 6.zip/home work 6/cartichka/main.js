
import { getData } from "./assinhron.js ";
getData()